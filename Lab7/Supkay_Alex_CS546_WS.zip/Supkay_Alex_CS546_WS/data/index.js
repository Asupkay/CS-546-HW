const recipeData = require("./recipes");

module.exports = {
    recipes: recipeData
};
